<?php get_header(); ?>

    <h1>Coucou</h1>

<?php get_footer(); ?>