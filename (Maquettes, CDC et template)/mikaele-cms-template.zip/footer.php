        <footer class="footer">
            <p>Tous droits réservés  |  Mikaele MEKENESE  ©2021</p>
        </footer>

        <?php wp_footer(); ?>
    </body>
</html>